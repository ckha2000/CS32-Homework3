//
//  main.cpp
//  Homework3-4
//
//  Created by christopher kha on 2/9/19.
//  Copyright © 2019 christopher kha. All rights reserved.
//

int countIncludes(const double a1[], int n1, const double a2[], int n2)
{
    if(n2 <= 0){
        return 1;
    }
    if(n1 <= 0){
        return 0;
    }
    
    int count = 0;
    
    if(a1[0] == a2[0]){
        count += countIncludes(a1+1, n1-1, a2+1, n2-1);
    }
    count += countIncludes(a1+1, n1-1, a2, n2);

    return count;
}

// Exchange two doubles
void exchange(double& x, double& y)
{
    double t = x;
    x = y;
    y = t;
}

void divide(double a[], int n, double divider,
            int& firstNotGreater, int& firstLess)
{
    if (n < 0)
        n = 0;
    
    firstNotGreater = 0;
    firstLess = n;
    int firstUnknown = 0;
    while (firstUnknown < firstLess)
    {
        if (a[firstUnknown] < divider)
        {
            firstLess--;
            exchange(a[firstUnknown], a[firstLess]);
        }
        else
        {
            if (a[firstUnknown] > divider)
            {
                exchange(a[firstNotGreater], a[firstUnknown]);
                firstNotGreater++;
            }
            firstUnknown++;
        }
    }
}

// Rearrange the elements of the array so that
// a[0] >= a[1] >= a[2] >= ... >= a[n-2] >= a[n-1]
// If n <= 1, do nothing.
void order(double a[], int n)
{
    if(n <= 1)
        return;
    
    int notGreater, less = 0;
    divide(a, n, a[0], notGreater, less);
    
    order(a, notGreater);
    order(a+less, n-less);
}
